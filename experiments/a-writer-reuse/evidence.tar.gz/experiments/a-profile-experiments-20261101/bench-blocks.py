"""Focused paired native study: five randomized A/B pairs per block, plus A/A control."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import random
import statistics
import subprocess

here = Path(__file__).resolve().parent
repo = here.parents[1]
spec = importlib.util.spec_from_file_location("a_bench", repo / "experiments/a-x86-speed/bench.py")
bench = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bench)
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--variants", default="control,cold-init,thin-init,reserved-writer,output-reuse,reserved-reuse")
parser.add_argument("--data-seed", type=int, choices=(1, 2, 3), default=1)
parser.add_argument("--blocks", type=int, default=15)
parser.add_argument("--shuffle", type=int, default=1136)
parser.add_argument("--skip-build", action="store_true")
parser.add_argument("--label", default="blocks")
args = parser.parse_args()
variants = args.variants.split(",")
assert len(variants) == len(set(variants)) and "baseline" not in variants
expected = {1: "495ca09682b9673ef836a506496177680bb4a3af54255174befddb1f83481cd3",
            2: "fe3469ff108066bd7b65f8239bbe27615467b99db182b79919c572c3d2910127",
            3: "5207056c6c7479374bc695261be9c4d37e13f2e49ece1f27669694ab122bcb24"}[args.data_seed]
data = Path(f"/inputs/full-seed{args.data_seed}")
out = repo / ".out/blocks"
out.mkdir(parents=True, exist_ok=True)
target = repo / "experiments/a-x86-speed/target"
target.mkdir(exist_ok=True)
results = here / "results"
results.mkdir(exist_ok=True)
report_path = results / f"{args.label}-seed{args.data_seed}.json"
names = ["baseline", *[x for x in variants if x != "control"]]
bins = {n: target / f"bench-{n}" for n in names}
for name in names:
    if not args.skip_build:
        subprocess.run(["rustc", *bench.RUSTFLAGS, "--crate-name", "solution", "-o", str(bins[name]), str(here / f"{name}.rs")], check=True)
bins["control"] = bins["baseline"]
report = {"complete": False, "all_hashes_ok": False, "config": vars(args),
          "note": "Five randomized adjacent A/B pairs per block. Ratio compares each side's mean middle three of five. Local VM only; block bootstrap does not prove independence or official score.",
          "input_sha256": bench.sha256(data / "requests.log"), "expected_output_sha256": expected,
          "sources": {n: {"source_sha256": bench.sha256(here / f"{n}.rs"), "binary_sha256": bench.sha256(bins[n])} for n in names},
          "pairs": [], "summary": {}}
rng = random.Random(args.shuffle)

def save():
    report_path.write_text(json.dumps(report, indent=1) + "\n")

def middle_three(samples):
    return statistics.fmean(sorted(x["wall"] for x in samples)[1:4])

save()
for threads in (16, 20):
    for block in range(-1, args.blocks):
        order = variants[:]
        rng.shuffle(order)
        for name in order:
            samples = {"baseline": [], "candidate": []}
            pair_order = []
            for repeat in range(5):
                sides = ["baseline", "candidate"]
                rng.shuffle(sides)
                pair_order.append(sides)
                for side in sides:
                    binary = bins["baseline" if side == "baseline" else name]
                    samples[side].append(bench.run_once(binary, data, out, threads, expected))
            base = middle_three(samples["baseline"])
            candidate = middle_three(samples["candidate"])
            report["pairs"].append({"threads": threads, "variant": name, "block": block,
                                     "warmup": block < 0, "pair_order": pair_order, "samples": samples,
                                     "baseline_middle3_s": base, "candidate_middle3_s": candidate,
                                     "ratio": candidate / base})
        save()
    summary = {}
    for name in variants:
        rows = [x for x in report["pairs"] if x["threads"] == threads and x["variant"] == name and not x["warmup"]]
        ratios = [x["ratio"] for x in rows]
        boot_rng = random.Random(1138)
        boot = sorted(statistics.median(boot_rng.choices(ratios, k=len(ratios))) for _ in range(3000))
        summary[name] = {"median_ratio": statistics.median(ratios), "mean_ratio": statistics.fmean(ratios),
                         "bootstrap95": [boot[75], boot[2924]], "win_fraction": sum(r < 1 for r in ratios) / len(ratios)}
        print(f"seed={args.data_seed} threads={threads} {name}: {summary[name]}", flush=True)
    report["summary"][str(threads)] = summary
    save()
report["complete"] = True
report["all_hashes_ok"] = all(s["sha256"] == expected for p in report["pairs"] for side in p["samples"].values() for s in side)
save()
print(f"Focused blocks seed{args.data_seed} complete", flush=True)

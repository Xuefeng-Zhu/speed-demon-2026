#!/usr/bin/env python3
"""Native exact-source scanner/equality properties; no performance claim.

Compiles each candidate with only main renamed, plus its actual scanner body
and a test main. No Docker, SSH or VM operation is invoked by this helper.
"""

import argparse
import hashlib
import platform
import subprocess
import tempfile
from pathlib import Path


VARIANTS = ("baseline", "scan32", "equal32", "scan-equal32")

TAIL = r'''
fn property_dictionary() -> Dictionary {
    Dictionary {
        slots: (0..4096).map(|_| OnceLock::new()).collect(),
        next_id: AtomicU32::new(0),
    }
}

fn property_input(len: usize, offset: usize, filler: u8) -> Vec<u8> {
    let mut input = vec![filler; offset + 129];
    input[offset] = b'/';
    input[offset + 1..offset + len].fill(b'a');
    input[offset + len] = b' ';
    input
}

fn property_lengths_alignments_mismatches() -> u64 {
    let mut checks = 0;
    for len in 1..=125 {
        let dictionary = property_dictionary();
        for offset in 0..32 {
            let input = property_input(len, offset, if offset % 2 == 0 { b'Z' } else { b'Y' });
            assert_eq!(property_endpoint_end(&input, offset), offset + len);
            assert_eq!(dictionary.find(&input, 0, offset, offset + len), 0);
            checks += 2;
            for mismatch in 0..len {
                let mut changed = input.clone();
                changed[offset + mismatch] = b'B';
                assert_eq!(property_endpoint_end(&changed, offset), offset + len);
                assert_eq!(dictionary.find(&changed, 0, offset, offset + len), mismatch as u32 + 1);
                assert_eq!(dictionary.find(&input, 0, offset, offset + len), 0);
                checks += 3;
            }
        }
        assert_eq!(dictionary.next_id.load(Ordering::Relaxed), len as u32 + 1);
        checks += 1;
    }
    // Every proper-prefix pair exists in the same forced-collision dictionary.
    let dictionary = property_dictionary();
    for offset in 0..32 {
        for len in 1..=125 {
            let input = property_input(len, offset, b'X');
            assert_eq!(dictionary.find(&input, 0, offset, offset + len), len as u32 - 1);
            checks += 1;
        }
    }
    assert_eq!(dictionary.next_id.load(Ordering::Relaxed), 125);
    checks + 1
}

fn property_guard_pages() -> u64 {
    extern "C" {
        fn getpagesize() -> i32;
        fn mprotect(address: *mut u8, length: usize, prot: i32) -> i32;
        fn munmap(address: *mut u8, length: usize) -> i32;
    }
    let mut checks = 0;
    unsafe {
        let page = getpagesize() as usize;
        let mapping = mmap(std::ptr::null_mut(), page * 2, 3, 2 | 0x20, -1, 0);
        assert_ne!(mapping as isize, -1);
        assert_eq!(mprotect(mapping.add(page), page, 0), 0);
        let readable = std::slice::from_raw_parts_mut(mapping, page);
        let dictionary = property_dictionary();
        for alignment in 0..32 {
            let start = page - 128 - alignment;
            for len in 1..=125 {
                readable.fill(b'Z');
                readable[start] = b'/';
                readable[start + 1..start + len].fill(b'a');
                readable[start + len] = b' ';
                assert_eq!(property_endpoint_end(readable, start), start + len);
                assert_eq!(dictionary.find(readable, 0, start, start + len), len as u32 - 1);
                checks += 2;
            }
        }
        // Exercise each actual equality span directly against the protected page.
        // The scan-only candidate still needs the baseline's 64-byte equality span.
        for len in 1..=125 {
            let window = if PROPERTY_SHORT_EQUALITY && len < 32 { 32 } else if len < 64 { 64 } else { 128 };
            let start = page - window;
            readable.fill(b'Y');
            readable[start] = b'/';
            readable[start + 1..start + len].fill(b'a');
            readable[start + len] = b' ';
            assert_eq!(dictionary.find(readable, 0, start, start + len), len as u32 - 1);
            checks += 1;
        }
        if PROPERTY_SHORT_SCAN {
            for len in 1..32 {
                let start = page - 32;
                readable.fill(b'X');
                readable[start] = b'/';
                readable[start + 1..start + len].fill(b'a');
                readable[start + len] = b' ';
                assert_eq!(property_endpoint_end(readable, start), start + len);
                checks += 1;
            }
        }
        assert_eq!(munmap(mapping, page * 2), 0);
    }
    checks
}

fn main() {
    let checks = property_lengths_alignments_mismatches() + property_guard_pages();
    println!("PASS {checks} exact scanner/equality checks: lengths 1..125, 32 alignments, every mismatch byte, forced hash collisions, prefixes and page guards");
}
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--variants", nargs="+", choices=VARIANTS,
                        default=["scan32", "equal32", "scan-equal32"])
    args = parser.parse_args()
    if platform.system() != "Linux" or platform.machine().lower() not in ("x86_64", "amd64"):
        parser.error("requires native Linux x86-64")
    if "avx2" not in Path("/proc/cpuinfo").read_text().lower().split():
        parser.error("CPU must report AVX2")
    here = Path(__file__).resolve().parent
    flags = ["--edition=2021", "-C", "opt-level=3", "-C", "lto=fat", "-C",
             "codegen-units=1", "-C", "panic=abort", "-C", "target-cpu=x86-64-v3",
             "--crate-name", "scanner_property", "-A", "dead_code"]
    with tempfile.TemporaryDirectory(prefix="a-scanner-property-") as directory:
        temporary = Path(directory)
        for name in args.variants:
            source = (here / f"{name}.rs").read_text()
            if source.count("fn main() {") != 1:
                raise ValueError("expected exactly one original main")
            start = source.index("        let mut e = s + ")
            end = source.index("        let h = hash(d, s, e - s);", start)
            scanner = "fn property_endpoint_end(d: &[u8], s: usize) -> usize {\n" + source[start:end] + "    e\n}\n"
            short_scan = "let mut e = s + eq_mask32(" in source
            short_equality = "&& if n < 32 {" in source
            constants = (f"const PROPERTY_SHORT_SCAN: bool = {str(short_scan).lower()};\n"
                         f"const PROPERTY_SHORT_EQUALITY: bool = {str(short_equality).lower()};\n")
            exact = source.replace("fn main() {", "fn solution_main() {", 1)
            program, binary = temporary / "main.rs", temporary / "property"
            program.write_text(exact + scanner + constants + TAIL)
            print(f"{name} source_sha256={hashlib.sha256(source.encode()).hexdigest()}", flush=True)
            subprocess.run(["rustc", *flags, str(program), "-o", str(binary)], check=True)
            subprocess.run([str(binary)], check=True)


if __name__ == "__main__":
    main()

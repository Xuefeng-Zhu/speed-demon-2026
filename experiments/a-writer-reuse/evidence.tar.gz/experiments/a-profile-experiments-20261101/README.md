# Track A experiments following the native profile

Fourteen isolated candidates were tried against production commit `ec8e317`.
The best native candidate is `reserved-reuse-4.rs`: all N workers still parse,
then one leaves before summary processing, while the writer recycles completed
output buffers through a pool retaining at most four idle buffers.

It improves central wall time consistently at 16 workers. Results at 20 workers
are smaller and less certain, and the greatest-of-five memory peak is slightly
higher. This is a candidate for an official-runner comparison, not an established
official score improvement. Production source was left at the measured baseline;
`candidate.patch` is a reviewable patch for the selected experimental source.

## Final candidate

Ratios below compare candidate/baseline; less than one is faster. Each block
contains five adjacent A/B pairs with randomized side order. Its ratio compares
the two independently sorted middle-three-of-five means. The table reports the
median of those block ratios, rather than a ratio of overall process medians.

| Full input | Blocks per worker count | 16-worker ratio | Improvement | 20-worker ratio | Improvement |
|---|---:|---:|---:|---:|---:|
| Seed 1, cap screen | 11 | 0.9355 | 6.5% | 0.9491 | 5.1% |
| Seed 2, fresh confirmation | 15 | 0.9287 | 7.1% | 0.9932 | 0.7% |
| Seed 3, fresh confirmation | 15 | 0.9445 | 5.6% | 0.9770 | 2.3% |

The first input selected the cap; the other two are follow-up comparisons. At
16 workers all three block-bootstrap intervals lie below one. At 20 workers the
seed-2 interval crosses one, so a uniform 20-worker win is not established.
Raw samples, A/A controls and exploratory intervals remain in
`results/cap-screen-seed1.json` and `cap-confirm-seed{2,3}.json`.

Five randomized native container memory runs per candidate and worker count:

| Workers | Baseline median / greatest peak, bytes | Candidate median / greatest peak, bytes | Greatest-peak change |
|---:|---:|---:|---:|
| 16 | 24,408,064 / 24,727,552 | 24,399,872 / 25,063,424 | +1.4% |
| 20 | 25,718,784 / 26,763,264 | 25,645,056 / 27,508,736 | +2.8% |

The median peaks are essentially flat; the greatest peaks are higher. This
measurement includes the solution, loader, shell/cat wrapper and charged output
pages. Input is warmed outside the measured container. It is not the official
parent-cgroup M and does not establish a K gain. See `results/memory-caps.json`.
Local formatted code lines increase from 398 to 412; official S may differ.

The candidate uses standard Rust ownership and synchronization. Workers pop an
optional buffer and allocate immediately if the pool is empty. The writer returns
a buffer only after its `write_all` completes; `summarize` clears its old length.
The four-buffer cap limits idle retention, not pending hours or worker lookahead.
It does not block workers waiting for a buffer or pin/reserve a physical CPU.
Buffers may grow to fit legal output, so four buffers is a count bound rather
than a fixed byte limit. N=1 preserves a summary worker and progress.

## What was tested

All candidates were generated from `baseline.rs`; unaffected variants retain
their source hashes across later studies.

| Candidate | Local code lines | Outcome |
|---|---:|---|
| `cold-init` | 407 | Explicit `get()` plus cold initializer; small CPU changes, inconsistent elapsed-time gains. |
| `get-first` | 402 | Inline initializer behind `get()`; no repeated wall-time win. |
| `thin-init` | 407 | Cold helper receives the exact name slice; no repeated wall-time win. |
| `scan32` | 411 | Roughly 7–10% slower in the wide screen. |
| `equal32` | 410 | Roughly 5–8% slower. |
| `scan-equal32` | 413 | Roughly 6–9% slower. |
| `late-free` | 398 | Delaying record frees loses roughly 2–9%. |
| `main-parse` | 407 | Main parses one chunk, then writes; results vary by input. Also changes summary concurrency. |
| `reserved-writer` | 401 | All workers parse; one exits after the second barrier. About 3% faster at 16 workers in focused blocks, essentially flat at 20. |
| `output-reuse` | 409 | Directionally faster at 20 workers, but its largest memory peak rises about 12.5% in the first memory study. |
| `reserved-reuse` | 412 | Combined central-time win on all three inputs; idle-pool retention raises greatest memory peaks about 8.3% / 10.8% at 16 / 20. |
| `reserved-reuse-1` | 412 | One idle buffer; seed-1 screen improves 16-worker time, but 20-worker result is weak. |
| `reserved-reuse-2` | 412 | Two idle buffers; promising seed-1 result, not independently confirmed. |
| `reserved-reuse-4` | 412 | Selected for confirmation and full validation; measured tradeoffs above. |

The original combined candidate's focused ratios were 0.9648 / 0.9317 / 0.9598
at 16 workers and 0.9825 / 0.9704 / 0.9703 at 20, for seeds 1/2/3. Its memory
cost motivated testing smaller idle pools instead of promoting the larger-pool
version. The four-buffer cap changes only the pool guard literal.

CPU measurements do not establish a hardware explanation for the failed parser
variants. No cache/branch hardware counters were available. Correctness passed
for those variants; the rejection is based on performance rather than semantics.

## Measurement and validation

- Native x86 VM, guest-reported Xeon Platinum 8573C, 8 cores / 16 logical CPUs,
  kernel 7.0.0-1017-azure. Guest metadata does not establish physical host placement.
  Twenty workers oversubscribe this VM, and the scoring machine differs.
- Pinned tool image:
  `halloumee/speed-demon-rust:1.99.1-trixie-llvm-tools@sha256:13e4ee7135d8eac6c56476c7d1aee201f36479f4745fd5d0e6b4529f4e13251a`.
  Python 3.13 and identical optimized x86-64-v3 Rust flags, with crate name
  `solution`. Benchmarks run inside the image, excluding Docker startup.
- Source baseline SHA-256:
  `d0c265b4aa458f4e00336215848115293be62e78d5a9f7d4703b4c8f35687221`.
  Selected source SHA-256:
  `40d5644ddd993cb1692c0eeb5f75e2cf3ab8b16b28c76d42fbd8013f46718614`.
- Initial screen: 31 measured shuffled rounds at 8/16/20 workers with baseline,
  byte-identical control and eight candidates. Confirmation: 81 seed-1 rounds
  and 41 each on seeds 2/3 for four finalists plus baseline/control.
- Focused study: 15 five-pair blocks per worker count across three inputs for
  the dictionary/concurrency/reuse ablations. Cap screen: 11 blocks on seed 1;
  selected-cap confirmation: 15 each on seeds 2/3. All use fresh shuffle seeds,
  recorded warmups and A/A controls.
- **11,516 timed solution outputs matched**, including 664 warmup outputs and
  10,852 measured outputs. The two completed memory studies add 60 checked
  outputs. Counts and the selected hash are in `results/validation-summary.json`.
- The selected source passed **55 end-to-end check groups**: 15 core checks
  (full input at eight worker settings, independent oracle, protected page ends,
  percentile/uint32 grid and four sample seeds against the official reference),
  20 adversarial checks, and 20 more after forcing every endpoint hash to zero.
  The original larger-pool combination, output reuse and reserved-writer each passed the
  same 55-check suite. See `correctness-cap4.json` and `correctness-original.json`.
- Three dictionary property runs passed concurrent same-key publication,
  1,842 forced-collision keys across 16 threads, dense-ID bijection, lengths,
  mismatches, wraparound and copied-name ownership. Three scanner property
  runs passed about 776k checks each, including all legal lengths, every mismatch
  position, 32 alignments, prefix cases and protected-page boundaries.
- The wide screen also ran 16 adversarial checks for each original candidate;
  three new ablations received those checks after the focused study.

The VM is noisy: an A/A median drift reached 4.4% in an earlier configuration,
and raw elapsed-time outliers reach multiple seconds. Prespecified trimming
measures central performance, not improved tail latency. Block-bootstrap
intervals are exploratory; correlated VM state and selecting among candidates
limit their interpretation. No profiler is attached to timing runs.

Shared-container guards interrupted two memory attempts; those partial results
are preserved separately and excluded from completed five-run summaries. One
post-benchmark formatting step failed because the tool image lacks `rustfmt`;
counts were obtained with the local formatter and its version is recorded.
A scratch-directory ownership issue interrupted the first forced-build stage;
the repaired harness subsequently completed all requested suites. Partial
reports remain distinguishable from reports with `complete: true`.

## Reproduction and review

`make-dictionary.py`, `make-scanner.py` and `make-structural.py` reproduce the
sources. Their notes document individual safety and memory implications.
`run-native.py` wraps the existing randomized benchmark and adversarial helper.
`bench-blocks.py` implements the focused study; the default label preserves the
original files, and `--label` keeps later studies separate. `verify-native.py`
records exact source/binary identities and full/forced-check results.
`memory-pairs.py` builds the normal pinned Track A images and records fresh
native cgroup peaks. It waits for other containers rather than stopping them.

Use a private copy on an otherwise idle native x86 VM, with the pinned image,
the included repository verification helpers and read-only full inputs mounted
at `/inputs/full-seed1`, `/inputs/full-seed2` and `/inputs/full-seed3`. Examples
inside the tool image, from the repository root:

```sh
python3 experiments/a-profile-experiments-20261101/run-native.py
python3 experiments/a-profile-experiments-20261101/bench-blocks.py --variants control,reserved-reuse-4 --data-seed 2 --blocks 15 --shuffle 1142 --label cap-confirm
python3 experiments/a-profile-experiments-20261101/verify-native.py --variants reserved-reuse-4 --label correctness-cap4
```

Memory runs execute as root on the native host because they launch restricted
Docker containers; pass `--data` with the host's full seed-1 directory,
`--variants baseline,reserved-reuse-4` and a fresh `--report` path. Memory runs
report no Docker elapsed time as application T. Keep benchmark and correctness
work serialized with other VM workloads. No host settings were changed and the
existing datasets were not modified.

`candidate.patch` applies the exact selected experimental source to
`track-a/src/main.rs`; `reserved-reuse.patch` preserves the earlier, larger-pool
prototype for comparison. Raw JSON and logs remain in `results/`.

#!/usr/bin/env python3
"""Recreate isolated initialized-slot lookup experiments from baseline.rs.

Writes only cold-init.rs, get-first.rs and thin-init.rs beside this script. --check verifies
that existing snapshots are reproducible without writing them. No compilation,
benchmark, Docker, Git, network or production-source operation is performed.
"""

import argparse
import hashlib
from pathlib import Path

BASELINE_SHA256 = "d0c265b4aa458f4e00336215848115293be62e78d5a9f7d4703b4c8f35687221"
ORIGINAL = '''            let entry = self.slots[i].get_or_init(|| {
                let id = self.next_id.fetch_add(1, Ordering::Relaxed);
                assert!(id < 2048, "more endpoints than the spec allows");
                let mut name = [0; 128];
                name[..n].copy_from_slice(&d[s..e]);
                Entry { hash: h, len: n as u32, id, name }
            });'''

COLD_LOOKUP = '''            let entry = if let Some(entry) = self.slots[i].get() {
                entry
            } else {
                self.initialize(i, d, h, s, e)
            };'''

COLD_HELPER = '''    // Cold discovery still initializes/waits on this exact slot. A competing
    // key may win it; find() therefore checks the returned key before probing on.
    #[cold]
    #[inline(never)]
    fn initialize(&self, i: usize, d: &[u8], h: u64, s: usize, e: usize) -> &Entry {
        self.slots[i].get_or_init(|| {
            let id = self.next_id.fetch_add(1, Ordering::Relaxed);
            assert!(id < 2048, "more endpoints than the spec allows");
            let mut name = [0; 128];
            name[..e - s].copy_from_slice(&d[s..e]);
            Entry { hash: h, len: (e - s) as u32, id, name }
        })
    }

'''

INLINE_LOOKUP = '''            let entry = if let Some(entry) = self.slots[i].get() {
                entry
            } else {
                self.slots[i].get_or_init(|| {
                    let id = self.next_id.fetch_add(1, Ordering::Relaxed);
                    assert!(id < 2048, "more endpoints than the spec allows");
                    let mut name = [0; 128];
                    name[..n].copy_from_slice(&d[s..e]);
                    Entry { hash: h, len: n as u32, id, name }
                })
            };'''

THIN_LOOKUP = '''            let entry = if let Some(entry) = self.slots[i].get() {
                entry
            } else {
                self.initialize(i, &d[s..e], h)
            };'''

THIN_HELPER = '''    // Only the exact endpoint slice crosses the cold-call boundary. Publication
    // and wait-on-this-slot semantics remain owned by the same OnceLock.
    #[cold]
    #[inline(never)]
    fn initialize(&self, i: usize, key: &[u8], h: u64) -> &Entry {
        self.slots[i].get_or_init(|| {
            let id = self.next_id.fetch_add(1, Ordering::Relaxed);
            assert!(id < 2048, "more endpoints than the spec allows");
            let mut name = [0; 128];
            name[..key.len()].copy_from_slice(key);
            Entry { hash: h, len: key.len() as u32, id, name }
        })
    }

'''


def variants(source):
    if source.count(ORIGINAL) != 1 or source.count("impl Dictionary {\n") != 1:
        raise SystemExit("baseline dictionary shape changed; review generator before adapting")
    cold = source.replace(ORIGINAL, COLD_LOOKUP)
    cold = cold.replace("impl Dictionary {\n", "impl Dictionary {\n" + COLD_HELPER, 1)
    thin = source.replace(ORIGINAL, THIN_LOOKUP)
    thin = thin.replace("impl Dictionary {\n", "impl Dictionary {\n" + THIN_HELPER, 1)
    return {"cold-init.rs": cold, "get-first.rs": source.replace(ORIGINAL, INLINE_LOOKUP),
            "thin-init.rs": thin}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--source", action="append", choices=("cold-init.rs", "get-first.rs", "thin-init.rs"),
                        help="generate/check only this snapshot; repeatable, default all three")
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    baseline = (here / "baseline.rs").read_bytes()
    if hashlib.sha256(baseline).hexdigest() != BASELINE_SHA256:
        raise SystemExit("baseline SHA-256 changed; expected the exact PR47 production source")
    for name, source in variants(baseline.decode()).items():
        if args.source and name not in args.source:
            continue
        target = here / name
        encoded = source.encode()
        if args.check:
            if not target.is_file() or target.read_bytes() != encoded:
                raise SystemExit(f"generated snapshot differs: {name}")
        else:
            target.write_bytes(encoded)
        print(f"{name} sha256={hashlib.sha256(encoded).hexdigest()}")


if __name__ == "__main__":
    main()

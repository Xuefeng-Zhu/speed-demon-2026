"""Summarize a randomized paired screen, including an identical-code noise control."""
import argparse
import json
from pathlib import Path
import random
import statistics

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("input", type=Path)
parser.add_argument("--output", type=Path)
args = parser.parse_args()
report = json.loads(args.input.read_text())
assert report["all_hashes_ok"]
result = {"input": str(args.input), "threads": {}, "note": "Exploratory paired median ratios. Bootstrap intervals assume resampled rounds; confirm candidates in independent runs."}
rng = random.Random(1137)
for threads in report["config"]["threads"]:
    rows = [r for r in report["rounds"] if r["threads"] == threads and not r["warmup"]]
    result["threads"][str(threads)] = {}
    for name in report["sources"]:
        ratios = [r["runs"][name]["wall"] / r["runs"]["baseline"]["wall"] for r in rows]
        boots = sorted(statistics.median(rng.choices(ratios, k=len(ratios))) for _ in range(3000))
        entry = {"paired_median": statistics.median(ratios), "bootstrap95": [boots[75], boots[2924]],
                 "win_fraction": sum(x < 1 for x in ratios) / len(ratios),
                 "wall_ms": statistics.median(r["runs"][name]["wall"] * 1000 for r in rows)}
        if "control" in report["sources"]:
            entry["median_vs_control"] = statistics.median(r["runs"][name]["wall"] / r["runs"]["control"]["wall"] for r in rows)
        result["threads"][str(threads)][name] = entry
        print(f"{threads:>2} {name:>14} {entry['wall_ms']:7.3f}ms ratio={entry['paired_median']:.4f} CI=[{boots[75]:.4f},{boots[2924]:.4f}] wins={entry['win_fraction']:.0%}")
if args.output:
    args.output.write_text(json.dumps(result, indent=2) + "\n")

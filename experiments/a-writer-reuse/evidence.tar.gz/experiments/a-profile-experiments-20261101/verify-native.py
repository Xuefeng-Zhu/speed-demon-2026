"""Native finalist correctness and forced-collision checks, outside timing runs."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

here = Path(__file__).resolve().parent
repo = here.parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--variants", required=True)
parser.add_argument("--label", default="correctness")
args = parser.parse_args()
target = here / "verify-target"
target.mkdir(exist_ok=True)
results = here / "results"
results.mkdir(exist_ok=True)
report = {"complete": False, "variants": {}, "stages": []}
path = results / f"{args.label}.json"
flags = ["--edition=2021", "--crate-name", "solution", "-C", "opt-level=3", "-C", "lto=fat",
         "-C", "codegen-units=1", "-C", "panic=abort", "-C", "target-cpu=x86-64-v3"]

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def save():
    path.write_text(json.dumps(report, indent=2) + "\n")

def run(label, command, expected=None):
    log = results / f"{args.label}-{label}.log"
    with log.open("w") as stream:
        process = subprocess.run(command, cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
    text = log.read_text(errors="replace")
    checks = sum(line.startswith("ok  ") for line in text.splitlines())
    passed = process.returncode == 0 and (expected is None or checks == expected)
    report["stages"].append({"label": label, "command": command, "returncode": process.returncode,
                             "observed_checks": checks, "expected_checks": expected,
                             "passed": passed, "log_sha256": digest(log)})
    save()
    print(f"{label}: {'PASS' if passed else 'FAIL'}, checks={checks}", flush=True)
    if not passed:
        print(text[-10000:], flush=True)
        raise RuntimeError(label)

save()
for name in args.variants.split(","):
    source = here / f"{name}.rs"
    binary = repo / "experiments/a-x86-speed/target" / f"bench-{name}"
    report["variants"][name] = {"source_sha256": digest(source), "binary_sha256": digest(binary)}
    run(f"{name}-core", [sys.executable, "-u", "experiments/a-x86-speed/check.py", str(binary),
                         "--data", "/inputs/full-seed1", "--threads", "1,2,3,6,8,16,20,default",
                         "--seeds", "2,98,999,4242"], 15)
    run(f"{name}-adversarial", [sys.executable, "-u", "experiments/a-x86-speed/adversarial.py",
                                "--binary", str(binary), "--spec", "--threads", "1,2,3,7,12"], 20)
    forced, count = re.subn(r"fn hash\(d: &\[u8\], s: usize, n: usize\) -> u64 \{.*?^\}",
                            "fn hash(_d: &[u8], _s: usize, _n: usize) -> u64 { 0 }",
                            source.read_text(), flags=re.S | re.M)
    assert count == 1, "forced-collision replacement must match exactly once"
    forced_source = target / f"{name}-forced.rs"
    forced_source.write_text(forced)
    forced_binary = target / f"{name}-forced"
    run(f"{name}-forced-build", ["rustc", *flags, str(forced_source), "-o", str(forced_binary)])
    run(f"{name}-forced-adversarial", [sys.executable, "-u", "experiments/a-x86-speed/adversarial.py",
                                       "--binary", str(forced_binary), "--spec", "--threads", "1,2,3,7,12"], 20)
    assert report["variants"][name]["source_sha256"] == digest(source)
    assert report["variants"][name]["binary_sha256"] == digest(binary)
    report["variants"][name].update({"forced_source_sha256": digest(forced_source),
                                     "forced_binary_sha256": digest(forced_binary), "checks_passed": 55})
    save()
report["complete"] = True
report["all_passed"] = all(stage["passed"] for stage in report["stages"])
save()

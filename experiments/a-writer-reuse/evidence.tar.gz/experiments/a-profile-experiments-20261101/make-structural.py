#!/usr/bin/env python3
"""Generate isolated structural experiments; never edits production or runs code."""
import hashlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE_SHA = "d0c265b4aa458f4e00336215848115293be62e78d5a9f7d4703b4c8f35687221"
base = (HERE / "baseline.rs").read_text()
assert hashlib.sha256(base.encode()).hexdigest() == BASE_SHA


def replace_once(source, old, new):
    assert source.count(old) == 1, old
    return source.replace(old, new, 1)


# Preserve exactly the existing buffers, algorithm and output; only the lifetime
# of the input record vectors within an active summarize call changes.
late = replace_once(base, "    drop(chunks);\n", "")
late = replace_once(late, "    out\n}\n\n/// The hours still to summarize", "    drop(chunks);\n    out\n}\n\n/// The hours still to summarize")
late = replace_once(
    late,
    "/// Formats every group of one hour from each chunk's records, freeing them as soon as they are\n/// sorted.",
    "/// Formats every group of one hour from each chunk's records, then frees the records after\n/// percentile selection and formatting.\n///",
)

# For N > 1 the main thread owns the last of the same N input chunks. All N
# participants publish parsed chunks, optionally build the plan, then cross the
# same two barriers. Only the spawned N-1 participants consume summary jobs.
main = replace_once(
    base,
    "    thread::scope(|s| {\n        for t in 0..threads {",
    "    thread::scope(|s| {\n        let worker_threads = if threads > 1 { threads - 1 } else { threads };\n        for t in 0..worker_threads {",
)
main = replace_once(
    main,
    "        drop(tx);\n        let (mut pending, mut written)",
    "        if worker_threads < threads {\n"
    "            let t = threads - 1;\n"
    "            *parsed[t].lock().unwrap() = parse(d, cuts[t], cuts[t + 1], &shared);\n"
    "            if barrier.wait().is_leader() {\n"
    "                let _ = plan.set(make_plan(&shared, &parsed));\n"
    "            }\n"
    "            barrier.wait();\n"
    "        }\n"
    "        drop(tx);\n        let (mut pending, mut written)",
)
main = replace_once(
    main,
    "    // The parse threads go on to summarize: after a barrier, one of them makes the plan, and after\n    // a second one all take hours from the queue.",
    "    // With multiple chunks the main thread parses the last chunk, then becomes the writer.\n"
    "    // Spawned workers summarize after the same two barriers and shared planning step.",
)

# Recycle only buffers whose write has completed. The pool never delays a job
# for an available buffer, and the pending-output channel remains unbounded.
reuse = replace_once(
    base,
    "fn summarize(hour: usize, chunks: Vec<Records>, order: &[u32], names: &[&[u8]], s: &mut Scratch) -> Vec<u8> {",
    "fn summarize(hour: usize, chunks: Vec<Records>, order: &[u32], names: &[&[u8]], s: &mut Scratch, recycled: Option<Vec<u8>>) -> Vec<u8> {",
)
reuse = replace_once(
    reuse,
    "    let mut out = Vec::with_capacity(1 << 18); // ample for one hour; untouched pages cost nothing",
    "    let mut out = recycled.unwrap_or_else(|| Vec::with_capacity(1 << 18));\n    out.clear();",
)
reuse = replace_once(
    reuse,
    "    let (tx, rx) = mpsc::channel();\n    thread::scope(|s| {",
    "    let (tx, rx) = mpsc::channel();\n    let output_pool = Mutex::new(Vec::<Vec<u8>>::new());\n    thread::scope(|s| {",
)
reuse = replace_once(
    reuse,
    "            let (tx, shared, parsed, plan, barrier) =\n                (tx.clone(), &shared, &parsed, &plan, &barrier);",
    "            let (tx, shared, parsed, plan, barrier, output_pool) =\n                (tx.clone(), &shared, &parsed, &plan, &barrier, &output_pool);",
)
reuse = replace_once(
    reuse,
    "                    tx.send((h, summarize(h, records, order, names, &mut scratch))).unwrap();",
    "                    let recycled = output_pool.lock().unwrap().pop();\n"
    "                    tx.send((h, summarize(h, records, order, names, &mut scratch, recycled))).unwrap();",
)
reuse = replace_once(
    reuse,
    "                f.write_all(&out).unwrap();\n                written += 1;",
    "                f.write_all(&out).unwrap();\n                written += 1;\n"
    "                let mut pool = output_pool.lock().unwrap();\n"
    "                if pool.len() < threads { pool.push(out); }",
)

# Keep all N spawned parsers, but reserve one logical worker's summary capacity
# for the existing main-thread writer. N=1 must retain its only summary worker.
reserved = replace_once(
    base,
    "                barrier.wait();\n                // Workers take whole hours",
    "                barrier.wait();\n"
    "                if threads > 1 && t == threads - 1 { return; }\n"
    "                // Workers take whole hours",
)
reserved_reuse = replace_once(
    reuse,
    "                barrier.wait();\n                // Workers take whole hours",
    "                barrier.wait();\n"
    "                if threads > 1 && t == threads - 1 { return; }\n"
    "                // Workers take whole hours",
)

for name, source in (("late-free", late), ("main-parse", main), ("output-reuse", reuse),
                     ("reserved-writer", reserved), ("reserved-reuse", reserved_reuse)):
    (HERE / f"{name}.rs").write_text(source)
    print(f"{name}.rs sha256={hashlib.sha256(source.encode()).hexdigest()}")

# Only the number of idle reusable buffers changes. This does not bound the
# jobs, pending output or workers, and a pool miss still allocates immediately.
for cap in (1, 2, 4):
    source = replace_once(
        reserved_reuse,
        "                if pool.len() < threads { pool.push(out); }",
        f"                if pool.len() < {cap} {{ pool.push(out); }}",
    )
    name = f"reserved-reuse-{cap}"
    (HERE / f"{name}.rs").write_text(source)
    print(f"{name}.rs sha256={hashlib.sha256(source.encode()).hexdigest()}")

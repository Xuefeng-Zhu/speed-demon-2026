#!/usr/bin/env python3
"""Generate isolated 32-byte scanner/equality candidates from the captured source.

Writes only scan32.rs, equal32.rs and scan-equal32.rs in this experiment folder.
No compiler, workload, VM, Docker or Git operation is invoked.
"""

import hashlib
from pathlib import Path


BASE_SHA256 = "d0c265b4aa458f4e00336215848115293be62e78d5a9f7d4703b4c8f35687221"

HELPER = '''/// A 32-byte version of `eq_mask`, for the bounded short-endpoint paths.
#[inline(always)]
fn eq_mask32(a: &[u8], i: usize, b: Option<(&[u8], usize)>, c: u8) -> u32 {
    assert!(i + 32 <= a.len() && b.map_or(true, |(b, j)| j + 32 <= b.len()));
    // SAFETY: loads are in bounds by the assert and unaligned; the build enables AVX2.
    unsafe {
        use std::arch::x86_64::*;
        let load = |d: &[u8], i: usize| _mm256_loadu_si256(d.as_ptr().add(i).cast());
        let other = b.map_or(_mm256_set1_epi8(c as i8), |(b, j)| load(b, j));
        _mm256_movemask_epi8(_mm256_cmpeq_epi8(load(a, i), other)) as u32
    }
}

'''

SCAN_OLD = '''        // The space after the endpoint, among the next 128 bytes (endpoints are at most 125).
        let mut e = s + eq_mask(d, s, None, b' ').trailing_zeros() as usize;
        if e == s + 64 {
            e += eq_mask(d, e, None, b' ').trailing_zeros() as usize;
        }
        assert!(e < s + 128, "endpoint longer than the spec allows");'''

SCAN_NEW = '''        // At most 128 bytes in 32/32/64-byte blocks; endpoints are at most 125.
        let mut e = s + eq_mask32(d, s, None, b' ').trailing_zeros() as usize;
        if e == s + 32 {
            e += eq_mask32(d, e, None, b' ').trailing_zeros() as usize;
            if e == s + 64 {
                e += eq_mask(d, e, None, b' ').trailing_zeros() as usize;
            }
        }
        assert!(e < s + 128, "endpoint longer than the spec allows");'''

EQUAL_OLD = "            if entry.hash == h && entry.len as usize == n && if n < 64 {"
EQUAL_NEW = '''            if entry.hash == h && entry.len as usize == n && if n < 32 {
                !eq_mask32(&entry.name, 0, Some((d, s)), 0) & ((1u32 << n) - 1) == 0
            } else if n < 64 {'''


def replace_once(source, old, new):
    if source.count(old) != 1:
        raise ValueError(f"expected exactly one occurrence: {old[:100]!r}")
    return source.replace(old, new, 1)


def main():
    here = Path(__file__).resolve().parent
    baseline = (here / "baseline.rs").read_text()
    observed = hashlib.sha256(baseline.encode()).hexdigest()
    if observed != BASE_SHA256:
        raise SystemExit(f"baseline changed: expected {BASE_SHA256}, got {observed}")
    marker = "/// Hash of the endpoint of `n` bytes at `s`, from its first and last words and length."
    common = replace_once(baseline, marker, HELPER + marker)
    for name, scan, equality in (("scan32", True, False), ("equal32", False, True),
                                 ("scan-equal32", True, True)):
        source = common
        if scan:
            source = replace_once(source, SCAN_OLD, SCAN_NEW)
        if equality:
            source = replace_once(source, EQUAL_OLD, EQUAL_NEW)
        (here / f"{name}.rs").write_text(source)
        print(f"{name}.rs sha256={hashlib.sha256(source.encode()).hexdigest()}")


if __name__ == "__main__":
    main()

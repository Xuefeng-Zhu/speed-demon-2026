# Isolated 32-byte scanner and equality experiments

The captured `baseline.rs` is production source `d0c265b4aa458f4e00336215848115293be62e78d5a9f7d4703b4c8f35687221` at `ec8e317`. Run `python3 experiments/a-profile-experiments-20261101/make-scanner.py` to recreate all three candidates. None changes the production source.

- `scan32.rs` finds the endpoint delimiter with one 32-byte mask first. On a miss it scans the next 32 bytes, and on a second miss uses the original 64-byte mask at offset 64. The scanned intervals are `[0,32)`, `[32,64)` and `[64,128)`, so coverage and the existing 128-byte rejection boundary are unchanged.
- `equal32.rs` changes only exact endpoint equality for lengths below 32: one 32-byte mask, with bits beyond the endpoint ignored. The original hash and length tests still precede equality. Lengths 32–125 retain the original comparison code exactly.
- `scan-equal32.rs` combines those two changes.

All variants add the same small, always-inline AVX2 `eq_mask32` helper. The fixed x86-64-v3 build enables AVX2; there is no new target fallback or runtime CPU dispatch. No table layout, publication, ID assignment, synchronization, timestamp, latency, record encoding, percentile, output or allocation policy changes.

## Bounds and exactness

`eq_mask32` asserts both 32-byte source spans before its unaligned loads. The existing file mapping has 4096 zero bytes of EOF padding. The longest scan reads through endpoint offset 127, exactly as the baseline does. Every valid endpoint has length 1–125 and a space at its actual end; a zero mask advances by the mask width because `u32::trailing_zeros(0)` is 32 and the original 64-bit helper returns 64.

Dictionary names remain 128-byte zero-padded arrays. For lengths 1–31, the mask is `(1u32 << n) - 1`, so the shift is below 32 and only exact endpoint bytes contribute. Length 32 uses the unchanged 64-byte branch. Length 64 uses the unchanged two-block long branch; its zero-bit second mask and both reads remain in bounds. Lengths 65–125 compare both blocks with only the final block's live bytes retained. Hash collisions still require full equality; no prefix or hash is accepted as identity.

The input shape measured for seed 1 has 49.16% of endpoints below 32 bytes and 93.83% below 64 bytes. The first 32-byte scanner therefore misses about half the time. Frequency alone does not establish branch misprediction or cache behavior. These are hypotheses for paired native measurements, not claimed improvements.

## Native correctness checks

`scanner-property.py` compiles the complete exact source with only its original `main` renamed and a property main appended. The scanner body is extracted from the actual parser. It checks all endpoint lengths, 32 alignments, exact collision equality and every first-mismatch position, proper prefixes, ignored bytes after names, and protected-page end layouts. Short-path-only guard checks are enabled only in the variants that actually implement them. It invokes no VM or Docker itself:

```sh
python3 experiments/a-profile-experiments-20261101/scanner-property.py
```

Use the normal native Linux x86-64-v3 GNU release settings and the same crate name for all candidates. The property helper does this automatically. It is correctness evidence only; timings from forced collisions or the property harness must not be treated as candidate performance. Full program/reference, adversarial and paired native measurements remain necessary before selecting a variant.

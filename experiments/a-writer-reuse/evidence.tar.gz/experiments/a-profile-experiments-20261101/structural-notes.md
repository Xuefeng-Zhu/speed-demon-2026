# Structural experiment variants

The structural variants and combinations are generated from `baseline.rs`, SHA-256
`d0c265b4aa458f4e00336215848115293be62e78d5a9f7d4703b4c8f35687221`, by
`python3 make-structural.py`. They preserve the dictionary, parser, packed-record
escapes, exact percentile algorithms, names and chronological output algorithm.
They are candidates for serialized native correctness and benchmarking, not
established improvements.

## `late-free.rs`

Moves the explicit `drop(chunks)` in `summarize` from immediately after latency
scatter to after the percentile and formatting loop, before returning `out`.
No record is read after scatter. The selected latencies live in the independent
`Scratch::lat` buffer, so keeping the source record vectors alive cannot change
the percentile or formatting values. Every vector is still freed by its summary
worker exactly once, before that hour's output is sent.

The hypothesis is that delaying frees allows each worker to complete its CPU
work before entering memory-management work that coincides with other workers'
allocation and fault activity. Frees can overlap other workers' work and writing
of earlier hours; this variant does **not** send the current hour before freeing
its records. It does not introduce a reclaimer thread, allocator settings or a
pool.

Memory can increase: the record vectors for each active hour now coexist with
that hour's formatted output. Extra retention is bounded by one currently active
hour per summary worker; it does not retain all completed hours' records. The
actual capacity and page residency matter, so measure the container/cgroup peak
and official M rather than inferring it from record count or process RSS.

Source SHA-256:
`d313675415960826d8319bb8a202b87629722a4fb7f49653a8829cc29d7894d0`.

## `main-parse.rs`

For requested worker count N > 1, spawns N−1 worker threads, and lets the main
thread parse the last of the original N input chunks. The main thread writes its
result into `parsed[N−1]` and takes part in both existing N-way barriers. Whichever
participant leads the first barrier builds and publishes the same plan. After
the second barrier, the main thread becomes the writer; the N−1 spawned workers
take the summary jobs through the unchanged queue.

For N = 1, spawns the original one parsing/summary worker and keeps the main
thread as writer, avoiding zero summary workers or a full-output buffering
fallback. N = 2 consequently uses one summary worker and may lose substantially
on summary throughput. This is a deliberate scheduling experiment, not a worker
count recommendation.

Safety and synchronization:

- Chunk cuts and total parse participant count are unchanged; each chunk is
  parsed once, and per-chunk input-page advice is unchanged.
- The main thread releases its parsed-result mutex before entering a barrier.
- The plan is published before all participants cross the second barrier, with
  the original `OnceLock`/barrier synchronization.
- The main thread keeps the original channel sender until after its parse and
  barriers, then drops it before receiving. Spawned worker senders still close
  the channel once all summary jobs are consumed.
- The shared dictionary and borrowed names outlive every scoped worker; scope
  joining and writer ordering are unchanged.
- There is no new buffer or queue. Fewer spawned workers means one fewer
  summary scratch buffer and thread stack; changing concurrency can nevertheless
  alter the observed peak/output backlog, so it still needs memory measurement.

The hypothesis is that avoiding dispatch of the last parse participant reduces
startup/off-CPU stragglers. It trades one summary worker for that possibility.
Main-thread parsing begins only after all helper spawns, so it is not guaranteed
to reduce the final parse finish or total wall time.

Source SHA-256:
`750b7dab1125d02234c82b68608a1d1c340224f9a18b35ff4d8a0e5f116aebff`.

## `output-reuse.rs`

Adds an opportunistic `Mutex<Vec<Vec<u8>>>` pool for formatted output buffers.
Immediately before each `summarize` call, a worker pops an optional buffer and
passes ownership to the function. At the original output-allocation point,
`summarize` allocates the original 256 KiB fallback only if no buffer was
available; it then clears the vector length before appending the new hour's
lines. Count, scatter, record freeing and percentile work are otherwise unchanged.

After a successful `write_all`, the writer returns the consumed output vector to
the pool only if the pool currently contains fewer than the requested N workers'
worth of buffers. If it is full, the vector is dropped normally. The mutex only
serializes short pool operations: workers never wait for the pool to become
nonempty, and a miss immediately takes the normal allocation path. Writes and
summary computation happen without holding the pool lock. Neither job scheduling
nor pending hours/channel capacity is bounded by this pool.

Ownership remains unique throughout worker → channel → pending hour → writer →
pool → worker. The writer pools an output only after `write_all` has consumed
its bytes, so no buffer is reused while it is still pending or being written.
Clearing the reused vector prevents any previous hour's bytes from becoming
part of the new output. Reuse adds no unsafe operations and does not touch
input ownership or dictionary lifetime.

The candidate reduces repeated output allocation/free calls when the writer can
return buffers soon enough. It deliberately retains up to N already-written
buffers that the baseline would have freed. The cap is in buffer count, not
bytes: original 256 KiB capacities would retain up to 4 MiB at N = 16, but
capacity growth and allocator residency must be measured. This is distinct from
the earlier bounded-output variants: it does not constrain pending hours,
lookahead or worker progress, and it may lose on added mutex work or peak memory.

Source SHA-256:
`29edceddf56ff745de5731b9bc557608f91520b5a87327ae02ae1e83ec1258eb`.

## `reserved-writer.rs`

Keeps the original N spawned parsing workers and main-thread writer. Immediately
after the second existing barrier, the last worker returns when N > 1, leaving
N−1 workers to summarize. N = 1 retains its only summary worker. This changes one
executable line in the baseline and isolates summary concurrency from the main
thread's parsing participation in `main-parse`.

All N chunks are parsed and published before the first barrier. The plan leader
still publishes the complete plan, and all N workers pass the second barrier
before any chosen worker exits. That worker has no scratch buffer or summary job
yet; returning drops its channel sender, while remaining workers continue to
send every queued hour. The original writer and scope joining are unchanged.

The candidate neither pins CPUs nor literally reserves a physical core. It
reduces concurrent summary workers by one, which may give the writer more
scheduling opportunity or reduce allocation contention. It may instead lose on
summary throughput. With fewer scratch buffers, memory use may change, but all
original parser stacks and record buffers still exist during parsing. Compare
against baseline and `main-parse` at the same requested N, including N = 1 and
N = 2, before assigning a gain to either parsing dispatch or summary concurrency.

Source SHA-256:
`d78643e43b2ce11a6cb229d4ab2698b0ac304e8a5a31275d127a1fd99c9dacd6`.

## `reserved-reuse.rs` combination

Combines the exact `output-reuse.rs` candidate with the single post-barrier exit
line from `reserved-writer.rs`. It therefore retains all N parsing workers,
uses N−1 summary workers when N > 1, and opportunistically reuses fully written
output vectors. N = 1 keeps its only summary worker. The pool cap remains the
requested thread count N, not the reduced summary count.

This is a separate composition hypothesis: reducing summary concurrency might
allow the writer to return buffers earlier, or the additional pool retention and
lock operations might erase a concurrency gain. The component measurements do
not establish the combination's result. Compare it against both components and
the baseline under the same paired release benchmark and memory measurement.
The independent source files are unchanged by generating this combination.

Source SHA-256:
`ac5e9e867c9f62946888cbd9369483288bfdf95acebad032521dd1e4aa1b0168`.

## `reserved-reuse-1.rs`, `reserved-reuse-2.rs`, `reserved-reuse-4.rs`

These are exact copies of `reserved-reuse.rs` except that the writer's idle-pool
guard uses the constant 1, 2 or 4 instead of `threads`. Each source has exactly
that single guard change; no other control flow, allocation site, worker count
or buffer ownership changes.

The original combination can retain up to N idle output buffers after the
writer has consumed them. These variants test whether a small idle pool keeps
useful reuse while avoiding that end-of-run retention. They still never wait
for the pool to become nonempty, and pool misses allocate immediately. There is
no bound on pending hours, channel capacity or worker lookahead. A full idle pool
only causes the already-written output vector to be dropped normally.

With unchanged 256 KiB buffer capacities, idle retention is at most 256 KiB,
512 KiB or 1 MiB respectively. These are not bounds on total output memory:
buffer capacities may grow, and active/pending vectors remain independent of
the idle pool. Native paired timing and container/cgroup peak measurements are
needed; a smaller cap can also increase allocation/free calls and lose speed.

Source SHA-256 values:

- `reserved-reuse-1.rs`:
  `f8966a164be664a079509c0cf648307281f71782f404d7c48d99f29f755fcee8`
- `reserved-reuse-2.rs`:
  `0e51648905b95d2934de64fd853efe777a2acd9f5fae787eeb1a48ad2f234eeb`
- `reserved-reuse-4.rs`:
  `40d5644ddd993cb1692c0eeb5f75e2cf3ab8b16b28c76d42fbd8013f46718614`

## Validation still required

No VM workload, Docker command or benchmark is run by the generator. Parent
coordination owns the native build and validation sequence. Prioritize thread
counts 1 and 2 for `main-parse`, then multiple-worker full input, empty/short
chunks, nonmonotonic hour arrivals, forced hash collisions and the existing
uint32/percentile/page-end cases. Check `output-reuse` on hours with decreasing
output sizes and sparse/empty groups to catch stale-buffer-length mistakes.
Compare all candidates independently against
the same release baseline before combining them with CPU-path experiments.

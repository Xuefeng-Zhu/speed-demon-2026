# Initialized-slot dictionary experiments

These three isolated variants start from the production Track A source captured
from `ec8e317`, byte-identical to the profiled PR #47 implementation. The exact
snapshot is `baseline.rs`, SHA-256
`d0c265b4aa458f4e00336215848115293be62e78d5a9f7d4703b4c8f35687221`.
Production code, parsing, hashing, equality, record encoding, summary logic and
thread coordination are unchanged by these experiments.

The profiling hypothesis is specific: the existing `get_or_init` call caused
initialization-closure captures to be stored before checking whether a probed
slot was already initialized. That setup accounted for 3.64% of the sampled
worker symbol in the 16-worker profile. The initialized-state load/check still
has to happen. Sampling percentages do not predict an equivalent wall-time gain.

## Variants

| File | Lookup behavior | Local formatted Rust lines |
|---|---|---:|
| `baseline.rs` | Existing `get_or_init` on every probe | 398 |
| `get-first.rs` | Explicit `get()` fast path; original initializer remains inline inside the miss branch | 402 |
| `cold-init.rs` | Explicit `get()` fast path; miss calls a `#[cold]`, `#[inline(never)]` initializer method | 407 |
| `thin-init.rs` | Same cold helper structure, passing the exact endpoint slice instead of the whole input and two offsets | 407 |

`get-first.rs` separates the effect of the explicit branch from moving the
initializer out of line. `cold-init.rs` aims to remove cold capture setup from
the initialized hot loop. The attributes express a compiler/code-layout choice;
generated assembly and native measurements must establish what actually changed.
Misses may do an extra readiness check, and the cold variant adds a call. These
costs matter during concurrent dictionary discovery.

`thin-init.rs` is a narrower ABI/code-layout comparison to `cold-init.rs`. Its
helper receives `&self`, the slot index, `&d[s..e]` and the hash. It derives the
length from that slice and copies its bytes into the same 128-byte owned name.
The slice is constructed only in the miss branch. This reduces the helper's
argument footprint; it does not establish fewer hot-path instructions or a
runtime improvement until the generated code and measurements are checked.

The line counts use local standard rustfmt followed by nonblank/non-line-comment
Rust-line counting. They are not complete official S values. These notes retain
the source counts without converting them into a score or a timing budget: the
owning scoring implementation and complete submission source accounting have
not been verified as part of this preparation. A tiny local timing difference
is insufficient evidence of a score improvement.

## Safety and concurrency

1. A successful `slot.get()` returns the same immutable, published `Entry` that
   the baseline uses. It does not create a separate cache or copy.
2. `get()` returning `None` can mean either an uninitialized slot or an
   initialization in progress. All three variants then invoke standard `get_or_init`
   on that exact slot. They retain its initialization/wait semantics.
3. A different key can win initialization of a collided slot. The original full
   hash, length and byte comparison remains after both branches; a mismatch
   advances the original linear probe sequence. An initializing slot is never
   skipped. Equal keys therefore cannot obtain duplicate entries by this change.
4. Only the winning initialization closure increments `next_id`. Its relaxed
   atomic operation provides unique IDs; publication still belongs to
   `OnceLock`. The ID bound and zero-padded name construction are unchanged.
5. The cold helpers' returned references are tied by Rust's method lifetime rules
   to `&self`, not the temporary input slice. Names are still copied into owned
   entries, and the dictionary outlives the borrowed summary names and workers.
   Existing name-load and input-padding bounds are unchanged.
   In `thin-init`, `key` is exactly the baseline endpoint range, and its bytes
   are copied before initialization returns; no reference to `key` is stored.
6. No new unsafe operation, custom atomic publication protocol, nested slot
   initialization or lock is introduced. Existing release `panic=abort` behavior
   remains in place; no panic/unwind recovery is added.

## Generation and checks

`make-dictionary.py` verifies the baseline hash and recreates only the three
dictionary variants in this directory. It rejects an unexpected baseline shape.
`--check` verifies reproducibility without writing files:

```sh
python3 experiments/a-profile-experiments-20261101/make-dictionary.py
python3 experiments/a-profile-experiments-20261101/make-dictionary.py --check
```

`--source thin-init.rs` generates/checks just the thin variant, leaving the
existing cold/get snapshot files untouched. Their source identities are retained.

Current generated source identities:

| File | SHA-256 |
|---|---|
| `get-first.rs` | `f4c4ecffa943057b484c9ab8398065a48c257087234a426152132d3c54fb0b98` |
| `cold-init.rs` | `b81c66a6da66e9ff8416970ec6a6ea0a6a6d64c5239379681b95cd938b3f3774` |
| `thin-init.rs` | `7fca4d615691265958190fe86fc89be3b38d10e600ef92a8e1751db2044d1e01` |

`dictionary-property.py` adapts the committed PR #47 shared-dictionary property
harness from `270871c`. It keeps the candidate source intact except for renaming
its application `main` in a temporary test program. It exercises:

- simultaneous discovery of one key by 32 threads and repeated initialized hits;
- 1,842 maximum-length keys forced into one collision chain, with 16 concurrent
  catalogue orders, consistent IDs and a dense-ID bijection;
- endpoint lengths 1–125, interior mismatches, alignment and probe wraparound;
- exact borrowed summary names after the input buffers are overwritten/freed.

Run it serially in the native Linux x86-64 pinned Rust environment with AVX2:

```sh
python3 experiments/a-profile-experiments-20261101/dictionary-property.py
```

The default checks all three variants. `--source cold-init.rs`,
`--source get-first.rs` or `--source thin-init.rs` selects one variant. The helper
prints the tested source hash, uses temporary build files and does not modify
the snapshots. The existing `experiments/a-x86-speed/check.py` and
`adversarial.py --spec` suites remain applicable to the resulting application
binaries; full datasets and alternate-seed/reference checks are still required.

Preparation checks are generation reproducibility, Python syntax and Rust
syntax through rustfmt. The preparation/extension tasks themselves do not run
native builds, properties or benchmarks. Execution results are recorded
separately under `results/`; this design note claims no speed or K improvement.

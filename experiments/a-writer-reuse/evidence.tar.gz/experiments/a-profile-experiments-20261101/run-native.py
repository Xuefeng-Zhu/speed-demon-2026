"""Compile/check/screen isolated Track A candidates inside the pinned native tool image."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

here = Path(__file__).resolve().parent
repo = here.parents[1]
os.chdir(repo)
assert platform.system() == "Linux" and platform.machine() == "x86_64"
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--variants", default="baseline,control,cold-init,get-first,scan32,equal32,scan-equal32,late-free,main-parse,output-reuse")
parser.add_argument("--runs", type=int, default=31)
parser.add_argument("--threads", default="8,16,20")
parser.add_argument("--seed", type=int, default=1131)
parser.add_argument("--data-seed", type=int, choices=(1, 2, 3), default=1)
parser.add_argument("--label", default="screen")
parser.add_argument("--skip-checks", action="store_true")
args = parser.parse_args()
names = args.variants.split(",")
assert names[0] == "baseline" and len(names) == len(set(names))
results = here / "results"
results.mkdir(exist_ok=True)
expected = {
    1: "495ca09682b9673ef836a506496177680bb4a3af54255174befddb1f83481cd3",
    2: "fe3469ff108066bd7b65f8239bbe27615467b99db182b79919c572c3d2910127",
    3: "5207056c6c7479374bc695261be9c4d37e13f2e49ece1f27669694ab122bcb24",
}[args.data_seed]

def run(command, label):
    log = results / f"{args.label}-{label}.log"
    with log.open("w") as stream:
        result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT)
    tail = log.read_text(errors="replace").splitlines()[-16:]
    print("\n".join(tail), flush=True)
    result.check_returncode()

command = [sys.executable, "-u", "experiments/a-x86-speed/bench.py"]
for name in names:
    source = "baseline" if name == "control" else name
    command += ["--variant", f"{name}={here.relative_to(repo)}/{source}.rs=--crate-name solution"]
command += ["--data", f"/inputs/full-seed{args.data_seed}", "--out", ".out/a-profile-experiments",
            "--threads", args.threads, "--runs", str(args.runs), "--warmup", "2", "--seed", str(args.seed),
            "--expected", expected, "--report", str(results / f"{args.label}.json")]
run(command, "benchmark")
benchmark = json.loads((results / f"{args.label}.json").read_text())
if "control" in names:
    assert benchmark["sources"]["control"]["binary_sha256"] == benchmark["sources"]["baseline"]["binary_sha256"], "control must be byte-identical"

if not args.skip_checks:
    for name in names:
        if name in ("baseline", "control"):
            continue
        binary = repo / "experiments/a-x86-speed/target" / f"bench-{name}"
        run([sys.executable, "-u", "experiments/a-x86-speed/adversarial.py", "--binary", str(binary),
             "--spec", "--threads", "1,3,16,20"], f"adversarial-{name}")

metadata = {"machine": platform.machine(), "kernel": platform.release(),
            "allowed_cpus": sorted(os.sched_getaffinity(0)),
            "lscpu": subprocess.check_output(["lscpu"], text=True),
            "rustc": subprocess.check_output(["rustc", "-Vv"], text=True),
            "python": platform.python_version(),
            "sources": {n: hashlib.sha256((here / (("baseline" if n == "control" else n) + ".rs")).read_bytes()).hexdigest() for n in names},
            "expected_output_sha256": expected, "complete": True}
(results / f"{args.label}-complete.json").write_text(json.dumps(metadata, indent=2) + "\n")
print(f"{args.label}: complete", flush=True)
